﻿using Entities;
using Library.Hw12.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data
{
    
    public class AppDbContext : DbContext
    {
        public DbSet<User> Users => Set<User>();
        public DbSet<Category> Categories => Set<Category>();
        public DbSet<Book> Books => Set<Book>();
        public DbSet<BorrowedBook> BorrowedBooks => Set<BorrowedBook>();
        public DbSet<Review> Reviews => Set<Review>();

       
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(connectionString: @"Server=LAPTOP-LCL3BM4M\SQLEXPRESS;Database=Liibrary;Integrated Security=true;TrustServerCertificate=true;");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            
            modelBuilder.Entity<User>(entity =>
            {
                entity.ToTable("Users");

                entity.HasKey(u => u.Id);

                entity.Property(u => u.Username)
                      .IsRequired()
                      .HasMaxLength(50);

                entity.Property(u => u.Password)
                      .IsRequired();

                entity.Property(u => u.Role)
                      .IsRequired();

                entity.HasMany(u => u.BorrowedBooks)
                      .WithOne(bb => bb.User)
                      .HasForeignKey(bb => bb.UserId);
                      

                entity.HasMany(u => u.Reviews)
                      .WithOne(r => r.User)
                      .HasForeignKey(r => r.UserId);
                      
            });

            
            modelBuilder.Entity<Category>(entity =>
            {
                entity.ToTable("Categories");

                entity.HasKey(c => c.Id);

                entity.Property(c => c.Name)
                      .IsRequired()
                      .HasMaxLength(100);

                entity.HasMany(c => c.Books)
                      .WithOne(b => b.Category)
                      .HasForeignKey(b => b.CategoryId);
                     
            });

            
            modelBuilder.Entity<Book>(entity =>
            {
                entity.ToTable("Books");

                entity.HasKey(b => b.Id);

                entity.Property(b => b.Title)
                      .IsRequired()
                      .HasMaxLength(200);

                entity.HasOne(b => b.Category)
                      .WithMany(c => c.Books)
                      .HasForeignKey(b => b.CategoryId);

                entity.HasMany(b => b.BorrowedBooks)
                      .WithOne(bb => bb.Book)
                      .HasForeignKey(bb => bb.BookId);


                entity.HasMany(b => b.Reviews)
                      .WithOne(r => r.Book)
                      .HasForeignKey(r => r.BookId);
                      
            });

            
            modelBuilder.Entity<BorrowedBook>(entity =>
            {
                entity.ToTable("BorrowedBooks");

                entity.HasKey(bb => bb.Id);

                entity.Property(bb => bb.BorrowedAt)
                      .IsRequired();
            });

           
            modelBuilder.Entity<Review>(entity =>
            {
                entity.ToTable("Reviews");

                entity.HasKey(r => r.Id);

                entity.Property(r => r.Comment)
                      .HasMaxLength(1000);

                entity.Property(r => r.Rating)
                      .IsRequired();

                entity.Property(r => r.CreatedAt)
                      .IsRequired();

                entity.Property(r => r.IsApproved)
                      .HasDefaultValue(false);

                entity.HasOne(r => r.User)
                      .WithMany(u => u.Reviews)
                      .HasForeignKey(r => r.UserId);

                entity.HasOne(r => r.Book)
                      .WithMany(b => b.Reviews)
                      .HasForeignKey(r => r.BookId);
            });
        }
    }
}
