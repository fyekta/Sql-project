﻿using Entities;
using Library.Hw12.Entities;
using Library.Hw12.Enum;
using Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class LibraryService : ILibraryService
    {
        private readonly IRepository _repository;

        public LibraryService(IRepository repository)
        {
            _repository = repository;
        }

        public void ShowLibraryMenu(User user)
        {
            if (user.Role == UserRole.Admin)
            {
                ShowAdminMenu(user);
            }
            else
            {
                ShowUserMenu(user);
            }
        }

        private void ShowUserMenu(User user)
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine(" Menu Library");
                Console.WriteLine("1. Show Categories And Books");
                Console.WriteLine("2. Borrow Book");
                Console.WriteLine("3. Show Borrowed book");
                Console.WriteLine("4. Add Review");
                Console.WriteLine("5. Edit Review");
                Console.WriteLine("6. Delete Review");
                Console.WriteLine("7. Show All Reviews");
                Console.WriteLine("0. Exit");

                Console.Write("Choose: ");
                var input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        ShowCategoriesAndBooks();
                        break;
                    case "2":
                        BorrowBook(user);
                        break;
                    case "3":
                        ShowUserBorrowedBooks(user);
                        break;
                    case "4":
                        AddReview(user);
                        break;
                    case "5":
                        EditReview(user);
                        break;
                    case "6":
                        DeleteReview(user);
                        break;
                    case "7":
                        ShowUserReviews(user);
                        break;
                    case "0":
                        return;
                    default:
                        Console.WriteLine("Eror");
                        Console.ReadKey();
                        break;
                }
            }
        }

        private void ShowAdminMenu(User admin)
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine(" Menu Admin");
                Console.WriteLine("1. Add Category");
                Console.WriteLine("2. Add Book");
                Console.WriteLine("3. Show All Categories And Books");
                Console.WriteLine("4. Manage Reviews");
                Console.WriteLine("0. Exit");

                Console.Write("choose: ");
                var input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        AddCategory();
                        break;
                    case "2":
                        AddBook();
                        break;
                    case "3":
                        ShowAllCategoriesAndBooks();
                        break;
                    case "4":
                        ManageReviewsAdmin();
                        break;
                    case "0":
                        return;
                    default:
                        Console.WriteLine("Eror");
                        Console.ReadKey();
                        break;
                }
            }
        }

        private void ShowCategoriesAndBooks()
        {
            Console.Clear();
            Console.WriteLine("Show Categorie And Books:");

            var categories = _repository.GetAllCategories();

            if (categories.Count == 0)
            {
                Console.WriteLine("category not found.");
                Console.ReadKey();
                return;
            }

            foreach (var category in categories)
            {
                Console.WriteLine($"category: {category.Name}");

                var books = _repository.GetAllBooks()
                                       .Where(b => b.CategoryId == category.Id)
                                       .ToList();

                if (books.Count == 0)
                {
                    Console.WriteLine(" The book not found");
                }
                else
                {
                    foreach (var book in books)
                    {
                        Console.WriteLine($"book : {book.Title}");
                    }
                }
            }

            Console.WriteLine("Enter");
            Console.ReadKey();
        }

        private void BorrowBook(User user)
        {
            Console.Clear();
            Console.WriteLine("Borrow Book");

            var categories = _repository.GetAllCategories();

            if (categories.Count == 0)
            {
                Console.WriteLine("category not found");
                Console.ReadKey();
                return;
            }

            Console.WriteLine("categories:");
            foreach (var cat in categories)
            {
                Console.WriteLine($"{cat.Id}. {cat.Name}");
            }

            Console.Write("categoryId: ");
            if (!int.TryParse(Console.ReadLine(), out int categoryId))
            {
                Console.WriteLine("Eror.");
                Console.ReadKey();
                return;
            }

            var selectedCategory = categories.FirstOrDefault(c => c.Id == categoryId);
            if (selectedCategory == null)
            {
                Console.WriteLine("category not found.");
                Console.ReadKey();
                return;
            }

            var books = _repository.GetAllBooks()
                                   .Where(b => b.CategoryId == categoryId)
                                   .ToList();

            if (books.Count == 0)
            {
                Console.WriteLine("book not found.");
                Console.ReadKey();
                return;
            }

            Console.WriteLine("books:");
            foreach (var book in books)
            {
                Console.WriteLine($"{book.Id}. {book.Title}");
            }

            Console.Write("BookId: ");
            if (!int.TryParse(Console.ReadLine(), out int bookId))
            {
                Console.WriteLine("Eror.");
                Console.ReadKey();
                return;
            }

            var selectedBook = books.FirstOrDefault(b => b.Id == bookId);
            if (selectedBook == null)
            {
                Console.WriteLine("book not found.");
                Console.ReadKey();
                return;
            }

            
            var userBorrows = _repository.GetUserBorrowedBooks(user.Id);
            if (userBorrows.Any(bb => bb.BookId == bookId))
            {
                Console.WriteLine("You Borrowed this book");
                Console.ReadKey();
                return;
            }

            var borrowedBook = new BorrowedBook
            {
                UserId = user.Id,
                BookId = bookId,
                BorrowedAt = DateTime.Now
            };

            _repository.BorrowBook(borrowedBook);
            _repository.Save();

            Console.WriteLine("Done.");
            Console.ReadKey();
        }

        private void ShowUserBorrowedBooks(User user)
        {
            Console.Clear();
            Console.WriteLine("Your Bor:");

            var borrowedBooks = _repository.GetUserBorrowedBooks(user.Id);

            if (borrowedBooks.Count == 0)
            {
                Console.WriteLine("You have not borrowed any books.");
                Console.ReadKey();
                return;
            }

            foreach (var bb in borrowedBooks)
            {
                var book = _repository.GetBookById(bb.BookId);
                Console.WriteLine($" {book?.Title ?? "Eror"} | date: {bb.BorrowedAt:yyyy/MM/dd}");
            }

            Console.WriteLine("Enter");
            Console.ReadKey();
        }

        private void AddReview(User user)
        {
            Console.Clear();
            Console.WriteLine("AddReview");

            var books = _repository.GetAllBooks();

            if (books.Count == 0)
            {
                Console.WriteLine("not book.");
                Console.ReadKey();
                return;
            }

            Console.WriteLine("books:");
            foreach (var book in books)
            {
                Console.WriteLine($"{book.Id}. {book.Title}");
            }

            Console.Write("BookId: ");
            if (!int.TryParse(Console.ReadLine(), out int bookId))
            {
                Console.WriteLine("Eror");
                Console.ReadKey();
                return;
            }

            var selectedBook = books.FirstOrDefault(b => b.Id == bookId);
            if (selectedBook == null)
            {
                Console.WriteLine("Book not Found");
                Console.ReadKey();
                return;
            }

            Console.Write("Rate 1 - 5): ");
            if (!int.TryParse(Console.ReadLine(), out int rating) || rating < 1 || rating > 5)
            {
                Console.WriteLine("must be 1 - 5");
                Console.ReadKey();
                return;
            }

            Console.Write("Comment: ");
            string? comment = Console.ReadLine();

            var review = new Review
            {
                UserId = user.Id,
                BookId = bookId,
                Rating = rating,
                Comment = comment,
                CreatedAt = DateTime.Now,
                IsApproved = false 
            };

            _repository.AddReview(review);
            _repository.Save();

            Console.WriteLine("Done.");
            Console.ReadKey();
        }
        private void EditReview(User user)
        {
            Console.Clear();
            Console.WriteLine("Edit Review");

            var reviews = _repository.GetUserReviews(user.Id);
            if (reviews.Count == 0)
            {
                Console.WriteLine("Eror.");
                Console.ReadKey();
                return;
            }

            Console.WriteLine("Your Reviews:");
            foreach (var review in reviews)
            {
                var book = _repository.GetBookById(review.BookId);
                Console.WriteLine($"{review.Id}. book: {book?.Title ?? "Eror"} | Rate: {review.Rating} | Comment: {review.Comment}");
            }

            Console.Write("reviewId: ");
            if (!int.TryParse(Console.ReadLine(), out int reviewId))
            {
                Console.WriteLine("Eror.");
                Console.ReadKey();
                return;
            }

            var selectedReview = _repository.GetReviewById(reviewId);
            if (selectedReview == null || selectedReview.UserId != user.Id)
            {
                Console.WriteLine("Eror");
                Console.ReadKey();
                return;
            }

            Console.Write($"New Rate: {selectedReview.Rating}): ");
            if (!int.TryParse(Console.ReadLine(), out int newRating) || newRating < 1 || newRating > 5)
            {
                Console.WriteLine("must be 1 - 5");
                Console.ReadKey();
                return;
            }

            Console.Write(" Comment: ");
            string? newComment = Console.ReadLine();

            selectedReview.Rating = newRating;
            selectedReview.Comment = newComment;
            selectedReview.CreatedAt = DateTime.Now;
            selectedReview.IsApproved = false;

            _repository.UpdateReview(selectedReview);
            _repository.Save();

            Console.WriteLine("Done.");
            Console.ReadKey();
        }

        private void DeleteReview(User user)
        {
            Console.Clear();
            Console.WriteLine("Delete Review");

            var reviews = _repository.GetUserReviews(user.Id);
            if (reviews.Count == 0)
            {
                Console.WriteLine("Eror.");
                Console.ReadKey();
                return;
            }

            Console.WriteLine(" Your Reviews:");
            foreach (var review in reviews)
            {
                var book = _repository.GetBookById(review.BookId);
                Console.WriteLine($"{review.Id}. book: {book?.Title ?? "eror"} | Rate: {review.Rating} | Comment: {review.Comment}");
            }
            Console.Write("reviewId: ");
            if (!int.TryParse(Console.ReadLine(), out int reviewId))
            {
                Console.WriteLine("eror.");
                Console.ReadKey();
                return;
            }

            var selectedReview = _repository.GetReviewById(reviewId);
            if (selectedReview == null || selectedReview.UserId != user.Id)
            {
                Console.WriteLine("eror.");
                Console.ReadKey();
                return;
            }

            _repository.DeleteReview(reviewId);
            _repository.Save();

            Console.WriteLine("Done.");
            Console.ReadKey();
        }

        private void ShowUserReviews(User user)
        {
            Console.Clear();
            Console.WriteLine("Your Reviews:");

            var reviews = _repository.GetUserReviews(user.Id);
            if (reviews.Count == 0)
            {
                Console.WriteLine("Eror.");
                Console.ReadKey();
                return;
            }

            foreach (var review in reviews)
            {
                var book = _repository.GetBookById(review.BookId);
                var status = review.IsApproved ? "Confirmed" : "A waiting confirmation";
                Console.WriteLine($" book: {book?.Title ?? "eror"} | Rate: {review.Rating} | comment: {review.Comment} | Status: {status}");
            }

            Console.WriteLine("Enter");
            Console.ReadKey();
        }

        private void AddCategory()
        {
            Console.Clear();
            Console.WriteLine("Add category");

            Console.Write("name: ");
            string? name = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(name))
            {
                Console.WriteLine("Eror");
                Console.ReadKey();
                return;
            }

            var category = new Category
            {
                Name = name.Trim()
            };

            _repository.AddCategory(category);
            _repository.Save();

            Console.WriteLine("Done");
            Console.ReadKey();
        }

        private void AddBook()
        {
            Console.Clear();
            Console.WriteLine("Add book");

            var categories = _repository.GetAllCategories();
            if (categories.Count == 0)
            {
                Console.WriteLine("Eror");
                Console.ReadKey();
                return;
            }

            Console.WriteLine("categories:");
            foreach (var cat in categories)
            {
                Console.WriteLine($"{cat.Id}. {cat.Name}");
            }

            Console.Write("categoryId: ");
            if (!int.TryParse(Console.ReadLine(), out int categoryId))
            {
                Console.WriteLine("Eror");
                Console.ReadKey();
                return;
            }

            var selectedCategory = categories.FirstOrDefault(c => c.Id == categoryId);
            if (selectedCategory == null)
            {
                Console.WriteLine("Eror.");
                Console.ReadKey();
                return;
            }

            Console.Write("Title: ");
            string? title = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(title))
            {
                Console.WriteLine("Eror");
                Console.ReadKey();
                return;
            }

            var book = new Book
            {
                Title = title.Trim(),
                CategoryId = categoryId
            };

            _repository.AddBook(book);
            _repository.Save();

            Console.WriteLine("Done");
            Console.ReadKey();
        }

        private void ShowAllCategoriesAndBooks()
        {
            Console.Clear(); 
            Console.WriteLine("Show Al lCategories And Books:");

            var categories = _repository.GetAllCategories();

            if (categories.Count == 0)
            {
                Console.WriteLine("Eror");
                Console.ReadKey();
                return;
            }

            foreach (var category in categories)
            {
                Console.WriteLine($"category: {category.Name}");

                var books = _repository.GetAllBooks()
                                       .Where(b => b.CategoryId == category.Id)
                                       .ToList();

                if (books.Count == 0)
                {
                    Console.WriteLine(" Eror");
                }
                else
                {
                    foreach (var book in books)
                    {
                        var reviews = _repository.GetApprovedReviewsByBookId(book.Id);
                        double avgRating = reviews.Count > 0 ? reviews.Average(r => r.Rating) : 0;

                        Console.WriteLine($" {book.Title} | Avg Rate: {(avgRating > 0 ? avgRating.ToString("0.0") : "do not Rate")}");
                    }
                }
            }

            Console.WriteLine("Enter");
            Console.ReadKey();
        }

        private void ManageReviewsAdmin()
        {
            Console.Clear();
            Console.WriteLine(" Management Reviews");

            var pendingReviews = _repository.GetPendingReviews();

            if (pendingReviews.Count == 0)
            {
                Console.WriteLine("Eror");
                Console.ReadKey();
                return;
            }

            foreach (var review in pendingReviews)
            {
                var user = _repository.GetUserById(review.UserId);
                var book = _repository.GetBookById(review.BookId);

                Console.WriteLine($"review Id: {review.Id}");
                Console.WriteLine($"User: {user?.Username ?? "نامشخص"}");
                Console.WriteLine($"Book: {book?.Title ?? "نامشخص"}");
                Console.WriteLine($"Rate: {review.Rating}");
                Console.WriteLine($"Comment: {review.Comment}");
                Console.WriteLine($"Date: {review.CreatedAt:yyyy/MM/dd}");
                Console.WriteLine("-------------------------");

                Console.Write("Do you agree with this ? (y/n): ");
                var input = Console.ReadLine();
                if (input?.ToLower() == "y")
                {
                    review.IsApproved = true;
                    _repository.UpdateReview(review);
                }
                else if (input?.ToLower() == "n")
                {
                    _repository.DeleteReview(review.Id);
                }

                _repository.Save();
            }

            Console.WriteLine("Enter.");
            Console.ReadKey();
        }
    }

}
