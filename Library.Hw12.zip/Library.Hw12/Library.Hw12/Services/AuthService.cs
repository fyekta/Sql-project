﻿using Entities;
using Library.Hw12.Enum;
using Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
   
    public class AuthService : IAuthService
    {
        private readonly IRepository _repository;

        public AuthService(IRepository repository)
        {
            _repository = repository;
        }

        
        public void Register()
        {
            Console.Clear();
            Console.WriteLine("---- Register ----");

            Console.Write("Username: ");
            string? username = Console.ReadLine();

            Console.Write("Password: ");
            string? password = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                Console.WriteLine("Username and password cannot be empty.");
                Console.ReadKey();
                return;
            }

            var existingUser = _repository.GetUser(username, password);
            if (existingUser != null)
            {
                Console.WriteLine("This username is already registered.");
                Console.ReadKey();
                return;
            }

            Console.WriteLine("Select role:");
            Console.WriteLine("1. Admin");
            Console.WriteLine("2. User");
            Console.Write("Your choice (1 or 2): ");
            string? roleInput = Console.ReadLine();

            UserRole role = UserRole.User;
            if (roleInput == "1")
                role = UserRole.Admin;

            var user = new User
            {
                Username = username,
                Password = password,
                Role = role
            };

            _repository.RegisterUser(user);
            _repository.Save();

            Console.WriteLine("Registration successful.");
            Console.WriteLine($"Registered as: {user.Role}");
            Console.ReadKey();
        }

      
        public User? Login()
        {
            Console.Clear();
            Console.WriteLine("Login");

            Console.Write("Username: ");
            string? username = Console.ReadLine();

            Console.Write("Password: ");
            string? password = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                Console.WriteLine("Username and password cannot be null.");
                Console.ReadKey();
                return null;
            }

            var user = _repository.GetUser(username, password);

            if (user == null)
            {
                Console.WriteLine("Invalid username or password.");
                Console.ReadKey();
                return null;
            }

            Console.WriteLine($"Welcome {user.Username} ({user.Role})");
            Console.ReadKey();
            return user;
        }
    }
}