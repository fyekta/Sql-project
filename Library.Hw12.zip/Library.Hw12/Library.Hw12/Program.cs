﻿using Data;
using Repositories;
using Services;



var context = new AppDbContext();
var repository = new Repository(context);
var authService = new AuthService(repository);
var libraryService = new LibraryService(repository);

while (true)
{
    Console.Clear();
    Console.WriteLine(" Library");
    Console.WriteLine("1. Register");
    Console.WriteLine("2. Login");
    Console.WriteLine("0. Exit");

    Console.Write("Choose: ");
    var choice = Console.ReadLine();

    switch (choice)
    {
        case "1":
            authService.Register();
            break;

        case "2":
            var user = authService.Login();
            if (user != null)
            {
                libraryService.ShowLibraryMenu(user);
            }
            break;

        case "0":
            return;

        default:
            Console.WriteLine("Invalid option.");
            Console.ReadKey();
            break;
    }
}
