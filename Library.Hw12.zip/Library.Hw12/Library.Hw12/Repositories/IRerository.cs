﻿using Entities;
using Library.Hw12.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories
{
  
    public interface IRepository
    {
       
        void RegisterUser(User user);

        User? GetUser(string username, string password);

        User? GetUserById(int userId);

        List<Category> GetAllCategories();

        void AddCategory(Category category);

        List<Book> GetAllBooks();

        Book? GetBookById(int id);

        void AddBook(Book book);

        void BorrowBook(BorrowedBook borrowedBook);

        List<BorrowedBook> GetUserBorrowedBooks(int userId);

        void AddReview(Review review);

        void UpdateReview(Review review);

        void DeleteReview(int reviewId);

        List<Review> GetReviewsForBook(int bookId);

        List<Review> GetUserReviews(int userId);

        Review? GetReviewById(int reviewId);
        List<Review> GetPendingReviews(); 
        List<Review> GetApprovedReviewsByBookId(int bookId); 

        void Save();
    }
}
