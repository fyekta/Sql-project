﻿using Data;
using Entities;
using Library.Hw12.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories
{
    
    public class Repository : IRepository
    {
        private readonly AppDbContext _context;

        public Repository(AppDbContext context)
        {
            _context = context;
        }

        public void RegisterUser(User user)
        {
            _context.Users.Add(user);
        }

        public User? GetUser(string username, string password)
        {
            return _context.Users.FirstOrDefault(u => u.Username == username && u.Password == password);
        }

        public User? GetUserById(int userId)
        {
            return _context.Users.FirstOrDefault(u => u.Id == userId);
        }

        public List<Category> GetAllCategories()
        {
            return _context.Categories
                .Include(c => c.Books)
                .ToList();
        }

        public void AddCategory(Category category)
        {
            _context.Categories.Add(category);
        }

        public List<Book> GetAllBooks()
        {
            return _context.Books
                .Include(b => b.Category)
                .Include(b => b.Reviews)
                .ToList();
        }

        public Book? GetBookById(int id)
        {
            return _context.Books
                .Include(b => b.Reviews)
                .Include(b => b.Category)
                .FirstOrDefault(b => b.Id == id);
        }

        public void AddBook(Book book)
        {
            _context.Books.Add(book);
        }

        public void BorrowBook(BorrowedBook borrowedBook)
        {
            _context.BorrowedBooks.Add(borrowedBook);
        }

        public List<BorrowedBook> GetUserBorrowedBooks(int userId)
        {
            return _context.BorrowedBooks
                .Include(bb => bb.Book)
                .ThenInclude(b => b.Category)
                .Where(bb => bb.UserId == userId)
                .ToList();
        }

        public void AddReview(Review review)
        {
            _context.Reviews.Add(review);
        }

        public void UpdateReview(Review review)
        {
            _context.Reviews.Update(review);
        }

        public void DeleteReview(int reviewId)
        {
            var review = _context.Reviews.Find(reviewId);
            if (review != null)
            {
                _context.Reviews.Remove(review);
            }
        }

        public List<Review> GetReviewsForBook(int bookId)
        {
            return _context.Reviews
                .Include(r => r.User)
                .Where(r => r.BookId == bookId && r.IsApproved)
                .ToList();
        }

        public List<Review> GetUserReviews(int userId)
        {
            return _context.Reviews
                .Where(r => r.UserId == userId)
                .ToList();
        }

        public Review? GetReviewById(int reviewId)
        {
            return _context.Reviews.Find(reviewId);
        }
        
        public List<Review> GetPendingReviews()
        {
            return _context.Reviews
                           .Where(r => !r.IsApproved)
                           .ToList();
        }

        public List<Review> GetApprovedReviewsByBookId(int bookId)
        {
            return _context.Reviews
                           .Where(r => r.BookId == bookId && r.IsApproved)
                           .ToList();
        }

        public void Save()
        {
            _context.SaveChanges();
        }
    }
}