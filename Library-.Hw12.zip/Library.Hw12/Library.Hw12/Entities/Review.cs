﻿using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Hw12.Entities
{
    public class Review
    {
        public int Id { get; set; }

        public int UserId { get; set; }
        public User User { get; set; } = null!;

        public int BookId { get; set; }
        public Book Book { get; set; } = null!;

        public string? Comment { get; set; }
        public int Rating { get; set; } // عددی بین 1 تا 5
        public DateTime CreatedAt { get; set; }
        public bool IsApproved { get; set; } = false;
    }
}
