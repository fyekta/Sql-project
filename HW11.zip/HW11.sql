--1

--Select Name , Price From Products Where Price > 500;

--2

/*SELECT 
    YEAR(OrderDate) AS OrderYear,
    SUM(TotalAmount) AS TotalSales
FROM Orders
GROUP BY YEAR(OrderDate)
ORDER BY OrderYear;*/

--3

/*SELECT 
    c.name AS categoryname,
    SUM(o.TotalAmount) AS totalsales
FROM orders o
JOIN products p ON o.ProductId = p.id
JOIN categories c ON p.CategoryId = c.id
GROUP BY c.name
ORDER BY totalsales DESC;*/

--4
/*SELECT name, price
FROM products
ORDER BY price DESC*/

--5

/*SELECT 
    c.name AS customername,
    COUNT(o.id) AS ordercount
FROM customers c
LEFT JOIN orders o ON c.id = o.customerid
GROUP BY c.name
ORDER BY ordercount DESC;*/

--6

/*SELECT 
    c.name AS categoryname,
    AVG(p.price) AS averageprice
FROM products p
JOIN categories c ON p.categoryid = c.id
GROUP BY c.name
ORDER BY averageprice DESC;*/

--7

/*SELECT 
    p.name AS productname,
    c.name AS categoryname
FROM products p
JOIN categories c ON p.categoryid = c.id
ORDER BY productname ASC;*/

--8

/*SELECT 
    c.name AS categoryname,
    SUM(o.TotalAmount) AS totalsales2023
FROM orders o
JOIN Products p ON o.ProductId = p.id
JOIN Categories c ON p.CategoryId = c.id
WHERE YEAR(o.OrderDate) = 2023
GROUP BY c.name
ORDER BY totalsales2023 DESC;*/

--9

/*SELECT 
    YEAR(OrderDate) AS orderyear,
    MONTH(OrderDate) AS ordermonth,
    COUNT(*) AS ordercount
FROM orders
GROUP BY YEAR(OrderDate), MONTH(OrderDate)
ORDER BY orderyear, ordermonth;*/

--10

/*SELECT 
    c.name AS customername,
    COALESCE(SUM(o.Totalamount), 0) AS totalsales
FROM customers c
LEFT JOIN orders o ON c.Id = o.CustomerId
GROUP BY c.name
ORDER BY totalsales;*/

--11

/*SELECT 
    c.name AS categoryname,
    COUNT(o.Id) AS ordercount
FROM Categories c
LEFT JOIN Products p ON c.Id = p.CategoryId
LEFT JOIN Orders o ON p.Id = o.ProductId
GROUP BY c.name
ORDER BY ordercount DESC;*/

--12

/*SELECT 
    c.name AS customername,
    COUNT(o.Id) AS ordercount
FROM customers c
LEFT JOIN orders o ON c.Id = o.CustomerId
GROUP BY c.name
ORDER BY ordercount DESC;*/

--13

/*SELECT 
    YEAR(OrderDate) AS orderyear,
    COUNT(*) AS ordercount
FROM Orders
GROUP BY YEAR(orderdate)
ORDER BY orderyear;*/

--14

/*SELECT 
    p.name AS productname,
    COUNT(DISTINCT o.CustomerId) AS buyercount
FROM products p
JOIN orders o ON p.Id = o.ProductId
GROUP BY p.name
ORDER BY buyercount DESC;*/

